/*
 * ceservertest.h
 *
 *  Created on: Jul 1, 2013
 *      Author: eric
 */

#ifndef CESERVERTEST_H_
#define CESERVERTEST_H_

void *CESERVERTEST(void *argv[]);

#endif /* CESERVERTEST_H_ */
